# -*- coding: utf-8 -*-

from resources.lib.common.language import Language


class GetRequest:

    language: Language
    search_result_id: str = None
    file_url: str = None
