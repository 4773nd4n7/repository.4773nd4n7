# Universal Subs Kodi Plugin

> One ring to rule them all, one ring to find them,<br/>
> One ring to bring them all, and in the darkness bind them;<br/>
> In the Land of Mordor where the shadows lie.
