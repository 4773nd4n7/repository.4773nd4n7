# TODO

- Fix default detection of subtitle sync based on file and features
- Add support for additional subtitle providers; some candidates:
  - https://yts-subs.com
  - https://www.moviesubtitles.org/
  - https://www.tvsubs.net/
  - https://english-subtitles.org
  - https://subdl.com
  - https://www.italiansubs.net/
